document.querySelector('.b1').addEventListener('click', function() {
  document.querySelector('.cont1').classList.toggle('s-signup');
});