CREATE DATABASE Health;

USE Health;
CREATE TABLE `doctor` (
  user_id int(11) NOT NULL AUTO_INCREMENT,
first_name varchar(50) NOT NULL,
last_name varchar(50) NOT NULL,
age int(2) NOT NULL,
contact_no varchar(10) NOT NULL,
specialization varchar(20) NOT NULL,
practice int(2) NOT NULL,
email varchar(20) NOT NULL,
  user_name varchar(50) NOT NULL,
  user_password varchar(50) NOT NULL,
  PRIMARY KEY (user_id)
);

