package com.service;

import org.apache.log4j.Logger;
import org.springframework.orm.hibernate5.HibernateTemplate;

import com.pojo.User;



public class RegistrationService {
       
       private HibernateTemplate hibernateTemplate;
           private static Logger log = Logger.getLogger(RegistrationService.class);
       
           private RegistrationService() { }
       
           public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
               this.hibernateTemplate = hibernateTemplate;
           }

           
           @SuppressWarnings( { "unchecked", "deprecation" } )
           public boolean registerUser(User obj)
           {
              
              
              hibernateTemplate.save(obj);
                  //hibernateTemplate.getSessionFactory().getCurrentSession().getTransaction().commit();
              
              
              return true;
              
              
           }

}
